package hmdioy.com.hmdioy;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HmdioyApplication {

	public static void main(String[] args) {
		SpringApplication.run(HmdioyApplication.class, args);
	}

}
